
Clone China Boards ATmega32U4 Support
=====================================

This contains support for the following Clone China Boards with 32u4 based Arduino-compatible development boards:
* [ProMicro 5V]
* [ProMicro 3.3V]

### Installation Instructions ###

To add this support to your Arduino IDE, simply copy the "china_boards.1.0.0" folder, and all of its contents, 
into a "hardware" directory:

* Inside your Sketchbook directory
* Directory structure example for Windows: C:/Users/userName/Arduino/hardware/china-boards/avr
